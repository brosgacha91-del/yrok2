# Project rules

- Python 3.12+ is required.
- All public functions and methods must include complete type annotations for arguments and return values.
- Do not use `print()` in business logic; use `logging` or custom exceptions instead.
- Keep functions under 25 lines when practical.
- Run `ruff check .` and `pytest` before finishing any change.
- Favor explicit data validation and small, testable functions.
