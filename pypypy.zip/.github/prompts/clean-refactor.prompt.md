---
mode: edit
description: Refactor the selected code to improve clarity, validation, and compatibility while preserving public behavior.
---

Refactor the target code to be consistent with `.github/copilot-instructions.md`.

Requirements:

- preserve behavior unless the issue is a bug
- add or improve type annotations
- remove `print()` calls from business logic
- keep functions small and readable
- keep the public API compatible

After the refactor, run `ruff check .` and `pytest` and report any remaining issues.
