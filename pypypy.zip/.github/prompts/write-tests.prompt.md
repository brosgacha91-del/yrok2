---
mode: edit
description: Write focused pytest coverage for the selected code paths, including parameterized edge cases and invalid inputs.
---

Write unit tests in `tests/` using `pytest` and `@pytest.mark.parametrize` where useful.

Cover:

- valid inputs
- invalid inputs
- boundary values
- error handling and edge cases

Keep tests readable, deterministic, and focused on real behavioral expectations.
