---
mode: ask
description: Inspect the selected file and identify legacy issues, missing validation, and rule violations without changing code.
---

Analyze the selected legacy code. Focus on:

- hidden bugs and missing validation
- boundary conditions and invalid inputs
- violations of the project rules in `.github/copilot-instructions.md`
- obvious refactor opportunities that do not change behavior

Provide a concise review with concrete examples and a recommended fix plan.
