---
mode: agent
description: Migrate the selected order-processing module to Pydantic v2 using current documentation, tests, and Ruff.
---

Upgrade the selected order-processing module to Pydantic v2 in autonomous mode.

Before editing:

1. Use the Context7 MCP tools `resolve-library-id` and `get-library-docs` to retrieve current Pydantic v2 documentation for `BaseModel`, `Field`, `EmailStr`, `ConfigDict`, `computed_field`, validators, and `model_dump`.
2. If either Context7 tool is unavailable, state that explicitly and do not claim that Context7 was used. Use official Pydantic v2 documentation only as a transparent fallback.
3. Inspect the module and its callers/tests to preserve the established public behavior where compatible with validation.

Implement a Pydantic v2 model that validates non-empty order/customer/item fields, positive quantity and price, a valid email address, and an allowed order status. Calculate the order total from quantity and unit price. Use Pydantic v2 APIs; do not retain Pydantic v1 decorators, configuration, or serialization methods.

Update focused pytest coverage for valid and invalid inputs, calculated totals, and model serialization. Run `ruff check --fix .` and `pytest`; fix failures and rerun both commands. Report the documentation source used and the final validation results.
